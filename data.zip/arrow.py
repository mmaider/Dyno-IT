import pygame
import random
import os

pygame.init()
size = width, height = 600, 300 
screen = pygame.display.set_mode(size)
screen.fill((0, 0, 255))

running = True
clock = pygame.time.Clock()


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image = image.convert_alpha()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    return image


class GAME(pygame.sprite.Sprite):
    image = load_image("game_over.png")
    delta = 5
    flag = 0

    def __init__(self, group):
        super().__init__(group)
        self.image = GAME.image
        self.rect = self.image.get_rect()
        self.rect.x = -600
        self.rect.y = 0

    def update(self):
        if self.rect.x + GAME.delta > 0:
            GAME.delta = 0          
        self.rect = self.rect.move(GAME.delta, 0)

all_sprites = pygame.sprite.Group()
GAME(all_sprites)

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill((0, 0, 255))
    all_sprites.update()
    all_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(50)
pygame.quit()